var slider = document.getElementById("myRange");
var output = document.getElementById("value");

output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
  var color1 = this.value;
  var color2 = 100-color1;    

  var bg = 'linear-gradient(90deg, #D0BCFF, #D0BCFF '+color1+'%, #D0BCFF '+color1+'%, #49454F '+color1+'% , #49454F '+color2+'%)';
    
  slider.style.setProperty('background', bg);    
}

var slider2 = document.getElementById("myRange2");
var output2 = document.getElementById("value2");

output2.innerHTML = slider2.value;

slider2.oninput = function() {
    output2.innerHTML = this.value;
    var color1 = this.value;
    var color2 = 100-color1;    
    var bg = 'linear-gradient(90deg, #D0BCFF, #D0BCFF '+color1+'%, #D0BCFF '+color1+'%, #49454F '+color1+'% , #49454F '+color2+'%)';
    slider2.style.setProperty('background', bg); 
  }


