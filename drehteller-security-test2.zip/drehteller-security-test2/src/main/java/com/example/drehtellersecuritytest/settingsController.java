package com.example.drehtellersecuritytest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class settingsController {


    @GetMapping("/einstellungen")
    public String settings(){
        return "einstellungen";
    }

    @GetMapping("/display")
    public String display(){
        return "display";
    }

    @GetMapping("/wlan")
    public String wlan(){
        return "wlan";
    }
}
