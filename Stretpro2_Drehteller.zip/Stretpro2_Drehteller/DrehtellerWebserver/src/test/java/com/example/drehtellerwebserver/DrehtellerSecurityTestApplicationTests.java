package com.example.drehtellerwebserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrehtellerSecurityTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
