package com.example.drehtellerwebserver;

import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepository;
    private String userName;

    public void addUser(User userDaten){
        this.userRepository.save(userDaten);
    }

    public String getUserbyName(String name) {
        userName = String.valueOf(userRepository.byName(name));
        return userName;
    }



    public Optional<User> getUserPassword(String id) {
        return this.userRepository.findById(id);
    }

}
