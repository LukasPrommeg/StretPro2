package com.example.drehtellerwebserver;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Optional;
public interface UserRepository extends MongoRepository <User, String> {

    @Query("{_name:?0}")
    public  Optional<User> byName(String name);


}
