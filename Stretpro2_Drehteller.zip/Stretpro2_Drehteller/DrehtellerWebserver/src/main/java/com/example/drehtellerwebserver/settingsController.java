package com.example.drehtellerwebserver;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class settingsController {


    @GetMapping("/einstellungen")
    public String settings() {
        return "einstellungen";
    }

   @GetMapping("/navbar.html")
    public String display() {
        return "navbar";
    }



    @GetMapping("/wlan")
    public String wlan() {
        return "wlan";
    }

}
