var lineCount = 0;
var placeHolder;

loadData();

function updateVal(sliderID) {
    var slider = document.getElementById("slider" + sliderID);
    var output = document.getElementById("sliderVal" + sliderID);

    var val;
    var rest;

    if (sliderID == 3) {
        val = Math.round((slider.value - 1) / 9 * 100);
        rest = 100 - val;
        output.innerHTML = slider.value;
    } else {
        val = slider.value;
        rest = 100 - val;
        output.innerHTML = val + "%";
    }


    var bg = 'linear-gradient(90deg, #D0BCFF, #D0BCFF ' + val + '%, #D0BCFF ' + val + '%, #49454F ' + val + '% , #49454F ' + rest + '%)';
    slider.style.setProperty('background', bg);
}

function addLine(line = "API INPUT LINE") {

    var container = document.getElementById("lines");

    if (line == "API INPUT LINE") {
        line = document.getElementById("displaytext").value;
        document.getElementById("displaytext").value = "";
    }

    if (line.length == 0 || line.length > 20) {
        return;
    }

    if (lineCount == 0) {
        placeHolder = document.getElementById("placeholder");
        document.getElementById("placeholder").remove();
    }

    var lineCard = document.createElement("div");
    lineCard.classList.add("row", "card-item");;

    lineCard.id = "line" + lineCount;

    var lineText = lineCard.appendChild(document.createElement("div"));
    lineText.classList.add("card-item-text");
    lineText.innerHTML = line;

    var delBTN = lineCard.appendChild(document.createElement("button"));
    delBTN.classList.add("deleteBTN");
    delBTN.addEventListener('click', function () {
        var id = delBTN.parentElement.id.replace("line", "");
        removeLine(id);
    });
    delBTN.innerHTML = "Löschen";

    container.appendChild(lineCard);
    lineCount++;
}

function removeLine(id) {   
    document.getElementById("line" + id).remove();

    id++;
    for (let i = id; i < lineCount; i++) {
        var line = document.getElementById("line" + i);
        line.id = "line" + (i - 1);
    }
    lineCount--;
    if (lineCount == 0) {
        var container = document.getElementById("lines");
        container.appendChild(placeHolder);
    }
}


function sendData() {
    var test;
    var url = window.location.href.split(":");

    var apiURL = url[0] + ":" + url[1] + ":5005";

    var auth = {
        user: "APIUser",
        pass: "DEINEMUTTER"
    }

    var xhr = new XMLHttpRequest();
    xhr.open("POST", apiURL + "/auth", true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(auth));
    xhr.onload = () => {
        if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
                var _speed = document.getElementById("slider1").value;
                var _bright = document.getElementById("slider2").value;
                var _switch = parseInt(document.getElementById("slider3").value) + 5;

                var _lines = Array();

                for (let i = 0; i < lineCount; i++) {
                    var lineCard = document.getElementById("line" + i);
                    var line = lineCard.getElementsByTagName("div")[0].innerHTML;
                    _lines.push(line);
                }

                var input = {
                    token: xhr.responseText,
                    config: {
                        speed: _speed,
                        dimm: _bright,
                        timing: _switch,
                        lines: _lines
                    }
                };

                xhr.open("POST", apiURL+ "/updateConfig", true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.send(JSON.stringify(input));
                xhr.onload = () => {
                    if (xhr.readyState === xhr.DONE) {
                        if (xhr.status === 200) {
                            alert("Daten wurden ans Drehteller übermittelt!");
                        }
                    }
                };
                xhr.onerror = () => {
                    alert("Fehler bei der Datenübertragung!");
                };
            }
        }
    };
    xhr.onerror = () => {
        alert("Fehler bei der Datenübertragung!");
    };
}

async function loadData() {

    var url = window.location.href.split(":");

    var apiURL = url[0] + ":" + url[1] + ":5005";

    try {
        const response = await fetch(apiURL + "/getConfig");
        const data = await response.json();


        document.getElementById("slider1").value = data.speed;
        updateVal(1);
        document.getElementById("slider2").value = data.dimm;
        updateVal(2);
        document.getElementById("slider3").value = (data.timing - 5);
        updateVal(3);   	

        const linesArray = data.lines;
    const lineCount = linesArray.length;

    for (var i = 0; i < lineCount; i++) {
      addLine(linesArray[i]);
    }

    } catch (error) {
        alert("Fehler bei der Verbindung mit dem Drehteller!");
    }
}

function stopTeller() {
    var url = window.location.href.split(":");

    var apiURL = url[0] + ":" + url[1] + ":5005";
    var auth = {
        user: "APIUser",
        pass: "DrehtellerAPI"
    }

    var xhr = new XMLHttpRequest();
    xhr.open("POST", apiURL + "/auth", true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(auth));
    xhr.onload = () => {
        if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {

                var input = {
                    token: xhr.responseText,
                };

                var xhr2 = new XMLHttpRequest();
                xhr2.open("POST", apiURL + "/stopTeller", true);
                xhr2.setRequestHeader('Content-Type', 'application/json');
                xhr2.send(JSON.stringify(input));

                alert("Teller wird gestoppt!");
            }
        }
    };
    xhr.onerror = () => {
        alert("Fehler bei der Datenübertragung!");
    };
}