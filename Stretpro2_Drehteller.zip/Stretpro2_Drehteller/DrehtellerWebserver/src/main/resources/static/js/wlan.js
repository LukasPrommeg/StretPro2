function submit() {
    var _ssid = document.getElementById("ssid").value;
    var _password = document.getElementById("password").value;

    var url = window.location.href.split(":");

    var apiURL = url[0] + ":" + url[1] + ":5005";

    var auth ={
        user : "APIUser",
        pass : "DEINEMUTTER"
    }

    var xhr = new XMLHttpRequest();
    xhr.open("POST", apiURL + "/auth", true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(auth));
    xhr.onload = () => {
        if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
                var sel = document.getElementById("dropdownwlan")

                var input;

                if (sel.value == "WLAN") {
                    if (_ssid.length == 0) {
                        alert("Eingabe fehlerhaft!");
                        return 0;
                    }
                    apiURL += "/connectToWLAN";
                    input = {
                        token: xhr.responseText,
                        wlanDetails: {
                            ssid: _ssid,
                            password: _password
                        }
                    };
                    alert("Wechsel zum WLAN mit den eingegebenen Daten!\n Dies kann einige Minuten dauern!");
                }
                else {
                    apiURL += "/enableHotspot";
                    if (_password.length > 7) {
                        input = {
                            token: xhr.responseText,
                            wlanDetails: {
                                ssid: _ssid,
                                password: _password
                            }
                        };
                        alert("Wechsel zum Hotspot mit den eingegebenen Daten!\n Dies kann einige Minuten dauern!");
                    }
                    else if(_password.length > 0) {
                        alert("Eingabe fehlerhaft!");
                        return 0;
                    }
                    else{
                        input = {
                            token: xhr.responseText,
                        };
                        alert("Wechsel zum Hotspot mit den bestehenden Daten!\n Dies kann einige Minuten dauern!");
                    }
                }

                var xhr2 = new XMLHttpRequest();
                xhr2.open("POST", apiURL, true);
                xhr2.setRequestHeader('Content-Type', 'application/json');
                xhr2.send(JSON.stringify(input));
                xhr2.onerror = () => {
                    alert("Fehler bei der Datenübertragung!");
                };
            }
        }
    };
    xhr.onerror = () => {
        alert("Fehler bei der Datenübertragung!");
    };
}