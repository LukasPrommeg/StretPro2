package at.stretpro.drehtellerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrehtellerApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
