package at.stretpro.drehtellerapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WLANDetails {
    @JsonProperty("ssid")
    String SSID = "";

    @JsonProperty("password")
    String password = "";

    public String getSSID() {
        return SSID;
    }

    public void setSSID(String SSID) {
        this.SSID = SSID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
