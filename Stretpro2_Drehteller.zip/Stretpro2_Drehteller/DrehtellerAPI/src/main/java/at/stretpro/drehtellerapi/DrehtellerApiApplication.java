package at.stretpro.drehtellerapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrehtellerApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(DrehtellerApiApplication.class, args);
    }

}
