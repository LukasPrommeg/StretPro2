package at.stretpro.drehtellerapi;

public class RequestJSON {
    String token;
    Config config;

    WLANDetails wlanDetails;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Config getConfig() {
        return config;
    }

    public void setConfig(Config config) {
        this.config = config;
    }

    public WLANDetails getWlanDetails() {
        return wlanDetails;
    }

    public void setWlanDetails(WLANDetails wlanDetails) {
        this.wlanDetails = wlanDetails;
    }
}
