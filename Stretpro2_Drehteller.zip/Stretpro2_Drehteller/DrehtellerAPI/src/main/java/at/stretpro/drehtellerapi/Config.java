package at.stretpro.drehtellerapi;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.Id;

import java.util.ArrayList;
import java.util.List;

public class Config {

    @Id
    public String id;

    @JsonProperty("speed")
    int speed = 50;
    @JsonProperty("dimm")
    int dimm = 50;
    @JsonProperty("timing")
    double timing = 10.0;
    @JsonProperty("gap")
    int gap = 5;
    @JsonProperty("lines")
    List<String> lines = new ArrayList<>();

    public Config() {

    }

    public Config(int speed, int dimm, double timing, int gap, List<String> lines) {
        this.speed = speed;
        this.dimm = dimm;
        this.timing = timing;
        this.gap = gap;
        this.lines = lines;
    }

    public int getSpeed() {
        return speed;
    }
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public int getDimm() {
        return dimm;
    }
    public void setDimm(int dimm) {
        this.dimm = dimm;
    }
    public double getTiming() {
        return timing;
    }
    public void setTiming(double timing) {
        this.timing = timing;
    }
    public int getGap() {
        return gap;
    }
    public void setGap(int gap) {
        this.gap = gap;
    }
    public List<String> getLines() {
        return lines;
    }
    public void setLines(List<String> lines) {
        this.lines = lines;
    }
}
