package at.stretpro.drehtellerapi;

import java.nio.charset.Charset;
import java.util.Objects;
import java.util.Random;

public class AuthToken {
    private int ttl = 5;
    String token;

    boolean valid = false;
    Credentials validCredentials = new Credentials("APIUser", "DrehtellerAPI");

    public AuthToken(Credentials credentials) {
        if(Objects.equals(validCredentials.getPass(), credentials.getPass()) && Objects.equals(validCredentials.getUser(), credentials.getUser())) {
            valid = true;
            token = generateToken();
        }
    }
    private String generateToken() {
        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 16;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        return generatedString;
    }

    public boolean validate(Credentials credentials) {
        if(validCredentials == credentials) {
            valid = true;
        }
        return true;
    }

    public int getTtl() {
        return ttl;
    }

    public void setTtl(int ttl) {
        this.ttl = ttl;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
