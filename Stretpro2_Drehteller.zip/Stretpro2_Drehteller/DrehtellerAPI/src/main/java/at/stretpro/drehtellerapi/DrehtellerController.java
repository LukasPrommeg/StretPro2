package at.stretpro.drehtellerapi;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@CrossOrigin
@RestController
public class DrehtellerController {

    @Autowired
    ConfigService drehtellerService;
    List<String> usableTokens = new ArrayList<>();
    Config currentConfig;

    @PostConstruct
    public void init() {
        waitForStart(0);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/state")
    public String getState() {
        return "DREHTELLER API IS UP";
    }
    @RequestMapping(method = RequestMethod.POST, value = "/auth")
    public String auth(@RequestBody Credentials credentials) {
        AuthToken newToken = new AuthToken(credentials);
        if(newToken.valid) {
            usableTokens.add(newToken.getToken());
            return newToken.getToken();
        }
        return "NOT VALID";
    }
    @RequestMapping(method = RequestMethod.POST, value = "/updateConfig")
    public String updateConfig(@RequestBody RequestJSON body) {
        if(usableTokens.contains(body.getToken())) {
            usableTokens.remove(body.getToken());
            writeToTeller(body.getConfig());
            return "CONFIG UPDATED";
        }
        return "NO PERMISSION!";
    }
    @RequestMapping(method = RequestMethod.POST, value = "/showIP")
    public String showIP(@RequestBody RequestJSON body) {
        if(usableTokens.contains(body.getToken())) {
            usableTokens.remove(body.getToken());
            runPythonScript(getPathOfJAR() + "showip.py", null);
            return "SHOWING IP!";
        }
        return "NO PERMISSION!";
    }
    @RequestMapping(method = RequestMethod.POST, value = "/stopTeller")
    public String stopTeller(@RequestBody RequestJSON body) {
        if(usableTokens.contains(body.getToken())) {
            usableTokens.remove(body.getToken());
            runPythonScript(getPathOfJAR() + "stopTeller.py", null);
            return "STOPPING TELLER";
        }
        return "NO PERMISSION!";
    }
    @RequestMapping(method = RequestMethod.GET, value = "/getConfig")
    public Config getCurrentConfig() {
        return currentConfig;
    }
    @RequestMapping(method = RequestMethod.POST, value = "/enableHotspot")
    public String enableHotspot(@RequestBody RequestJSON body) {
        if(usableTokens.contains(body.getToken())) {
            usableTokens.remove(body.getToken());
            String bashpath = getPathOfJAR() + "networkConfig/zuHotspot.sh";
            if(body.getWlanDetails() == null) {
                runBashScript(bashpath,null);
            }
            else {
                runBashScript(bashpath,  new String[] {body.getWlanDetails().getSSID(), body.getWlanDetails().getPassword()});
            }
            runPythonScript(getPathOfJAR() + "stopTeller.py", null);

            new Thread(() -> {
                waitForStart(30);
            }).start();

            return "Switching to Hotspot!";
        }
        return "NO PERMISSION!";
    }
    @RequestMapping(method = RequestMethod.POST, value = "/connectToWLAN")
    public String connectToWLAN(@RequestBody RequestJSON body) {
        if(usableTokens.contains(body.getToken())) {
            usableTokens.remove(body.getToken());
            String bashpath = getPathOfJAR() + "networkConfig/addWlan.sh";
            runBashScript(bashpath, new String[] {body.getWlanDetails().getSSID(), body.getWlanDetails().getPassword()});
            runPythonScript(getPathOfJAR() + "stopTeller.py", null);
            return "Switching to existing WLAN!";
        }
        return "NO PERMISSION!";
    }
    private void waitForStart(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }

        Config savedConfig = readFromTeller();
        if(savedConfig != null) {
            currentConfig = savedConfig;
            writeToTeller(currentConfig);
        }
    }
    public void runBashScript(String bashPath, String[] arg) {
        System.out.print("RUNNING: " + bashPath);
        System.out.println();
        try{
            List<String> run = new ArrayList<>(List.of(new String[]{"sudo", "bash", bashPath}));
            if(arg != null) {
                Collections.addAll(run, arg);
            }

            Process p = Runtime.getRuntime().exec(run.toArray(new String[0]));
        }
        catch (Exception e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
    }
    public void runPythonScript(String pythonPath, String[] arg) {
        System.out.println("RUNNING: " + pythonPath);
        try{
            List<String> run = new ArrayList<>(List.of(new String[]{"python", pythonPath}));
            if(arg != null) {
                Collections.addAll(run, arg);
            }

            Process p = Runtime.getRuntime().exec(run.toArray(new String[0]));
        }
        catch (Exception e) {
            System.out.println("Something went wrong!");
        }
    }
    private String getPathOfJAR() {
        String execPath = getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
        execPath = execPath.substring(0, execPath.lastIndexOf("/"));
        execPath = execPath.replaceAll("%20"," "); // Surely need to do this here
        //System.out.println(execPath);
        String[] path = execPath.split("/");
        String jarPath = "/";
        for (int i = 1; i < path.length - 4; i++) {
            jarPath += path[i] + "/";
        }
        return jarPath;
    }
    private void writeToTeller(Config newConfig) {
        String jsonPath = getPathOfJAR();
        //System.out.println("WRITING TO: " + pythonPath);

        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File(jsonPath + "config.json"), newConfig);
            currentConfig = newConfig;
        }
        catch (Exception e) {
            System.out.println("Something went wrong!");
        }

        runPythonScript(getPathOfJAR() + "updateConfig.py", null);
    }
    private Config readFromTeller() {
        try{
            Path jsonPath = Path.of(getPathOfJAR() + "config.json");

            String json = Files.readString(jsonPath);

            ObjectMapper mapper = new ObjectMapper();
            Config config = mapper.readValue(json, Config.class);
            return config;
        }
        catch(Exception e) {
            System.out.println("Couldnt read JSON Config!");
        }
        return null;
    }

}
